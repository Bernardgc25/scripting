#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{

  printf("Hello world, this is a sample xv6 user program \n");
  exit(0);
}
